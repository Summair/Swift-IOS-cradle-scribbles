//
//  ViewController.swift
//  Personaity Quiz(by Mohammed)
//
//  Created by Mohammed Brohi on 3/21/19.
//  Copyright © 2019 Mohammed Brohi. All rights reserved.
//

import UIKit

class IntroductionViewController: UIViewController {
    @IBAction func unwindtoQuizIntroduction(segue: UIStoryboard){
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

